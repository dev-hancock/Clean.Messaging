namespace Clean.Messaging.Outbox;

public sealed record OutboxMessage<T>(
    Guid Id,
    T Message,
    Guid? CorrelationId = null,
    Guid? CausationId = null);

public sealed record OutboxEnvelope(
    Guid Id,
    string Type,
    object Payload,
    Guid? CorrelationId = null,
    Guid? CausationId = null);

public interface IOutbox
{
    void Enqueue<TMessage>(
        OutboxMessage<TMessage> message)
        where TMessage : notnull;
}
