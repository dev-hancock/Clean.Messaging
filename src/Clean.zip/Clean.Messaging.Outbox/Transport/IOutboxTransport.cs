namespace Clean.Messaging.Outbox.Transport;

public sealed record OutboxMessage(
    Guid MessageId,
    Guid EventId,
    string TargetId,
    string? Destination,
    string Contract,
    ReadOnlyMemory<byte> Payload,
    Guid? CorrelationId,
    Guid? CausationId);


public interface IOutboxTransport
{
    string Name { get; }

    ValueTask Dispatch(
        OutboxMessage message,
        CancellationToken cancellationToken);
}