﻿using Clean.Messaging.Contracts;
using Clean.Messaging.Transport;

namespace Clean.Messaging.Outbox.Dispatch;

internal sealed class TransportMessageFactory(
    IMessageContractRegistry contracts,
    ITransportSerializer serializer)
{
    public TransportMessage Create<TPayload>(
        Transport.OutboxMessage message,
        TPayload payload)
        where TPayload : notnull
    {
        return new()
        {
            MessageId = message.MessageId,
            EventId = message.EventId,

            Contract = contracts.GetContract(
                typeof(TPayload)),

            Payload = serializer.Serialize(
                payload),

            CorrelationId = message.CorrelationId,
            CausationId = message.CausationId
        };
    }
}