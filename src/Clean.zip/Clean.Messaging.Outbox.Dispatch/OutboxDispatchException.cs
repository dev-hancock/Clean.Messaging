﻿namespace Clean.Messaging.Outbox.Dispatch;

public sealed class OutboxDispatchException
    : Exception
{
    public OutboxDispatchException(
        string message)
        : base(message)
    {
    }

    public OutboxDispatchException(
        string message,
        Exception innerException)
        : base(
            message,
            innerException)
    {
    }
}