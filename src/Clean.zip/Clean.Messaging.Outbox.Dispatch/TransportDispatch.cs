﻿using Clean.Messaging.Outbox.Transport;
using Clean.Messaging.Serialization;
using Clean.Messaging.Transport;
using System.Text;

namespace Clean.Messaging.Outbox.Dispatch;


internal interface ITransportDispatch
{
    DispatchMap Map { get; }

    TransportMessage Create(
        OutboxMessage message);
}

internal sealed class TransportDispatch<
    TMessage,
    TPayload,
    TMapper>(
    IMessageSerializer serializer,
    TMapper mapper,
    TransportMessageFactory factory)
    : ITransportDispatch
    where TMessage : notnull
    where TPayload : notnull
    where TMapper :
    class,
    ITransportMapper<TMessage, TPayload>
{
    public DispatchMap Map { get; } =
        new(
            typeof(TMessage),
            typeof(TPayload));

    public TransportMessage Create(
        OutboxMessage message)
    {
        try
        {
            var source =
                Deserialize(
                    message);

            var payload =
                mapper.Map(
                    source);

            return factory.Create(
                message,
                payload);
        }
        catch (OutboxDispatchException)
        {
            throw;
        }
        catch (Exception exception)
        {
            throw new OutboxDispatchException(
                $"Outbox message '{message.Contract}' could not be mapped " +
                $"from '{typeof(TMessage)}' to '{typeof(TPayload)}'.",
                exception);
        }
    }

    private TMessage Deserialize(
        OutboxMessage message)
    {
        var data =
            new MessageData(
                message.Contract,
                Encoding.UTF8.GetString(
                    message.Payload.Span));

        var value =
            serializer.Deserialize(
                data);

        if (value is TMessage typed)
        {
            return typed;
        }

        throw new InvalidOperationException(
            $"Outbox message '{message.Contract}' deserialized as " +
            $"'{value.GetType()}' but dispatch expects '{typeof(TMessage)}'.");
    }
}