﻿using Clean.Messaging.Outbox.Transport;
using Clean.Messaging.Transport;

namespace Clean.Messaging.Outbox.Dispatch;

public interface IOutboxDispatch
{
    TransportMessage Create(
        DispatchMap map,
        OutboxMessage message);
}

internal sealed class OutboxDispatch(
    TransportDispatchRegistry registry)
    : IOutboxDispatch
{
    public TransportMessage Create(
        DispatchMap map,
        OutboxMessage message)
    {
        ArgumentNullException.ThrowIfNull(
            message);

        return registry
            .Get(map)
            .Create(
                message);
    }
}