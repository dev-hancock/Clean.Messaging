﻿using System.Collections.Frozen;

namespace Clean.Messaging.Outbox.Dispatch;

internal sealed class TransportDispatchRegistry(
    IEnumerable<ITransportDispatch> dispatches)
{
    private readonly FrozenDictionary<
        DispatchMap,
        ITransportDispatch> _dispatches =
        dispatches.ToFrozenDictionary(
            registration => registration.Map);

    public ITransportDispatch Get(
        DispatchMap map)
    {
        if (_dispatches.TryGetValue(
                map,
                out var dispatch))
        {
            return dispatch;
        }

        throw new OutboxDispatchException(
            $"No dispatch mapping is registered from " +
            $"'{map.MessageType}' to '{map.PayloadType}'.");
    }
}