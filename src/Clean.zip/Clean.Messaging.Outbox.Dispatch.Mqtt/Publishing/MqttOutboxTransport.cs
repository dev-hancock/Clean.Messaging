using Clean.Messaging.Outbox.Mqtt;
using Clean.Messaging.Outbox.Mqtt.Connection;
using Clean.Messaging.Outbox.Mqtt.Publishing;
using Clean.Messaging.Outbox.Mqtt.Routing;
using Clean.Messaging.Outbox.Transport;
using Microsoft.Extensions.Options;

namespace Clean.Messaging.Outbox.Dispatch.Mqtt.Publishing;

internal sealed class MqttOutboxTransport(
    MqttConnection connection,
    MqttRouteRegistry routes,
    IOptions<MqttOutboxOptions> options)
    : IOutboxTransport
{
    public string Name =>
        MqttTransport.Name;

    public async ValueTask Dispatch(
        OutboxMessage message,
        CancellationToken cancellationToken)
    {
        var route = routes.Get(
            message.TargetId);

        var client = await connection.GetClient(
            cancellationToken);

        var mqttMessage = MqttMessageFactory.Create(
            message,
            route,
            options.Value);

        var result = await client.PublishAsync(
            mqttMessage,
            cancellationToken);

        if (!result.IsSuccess)
        {
            throw new MqttPublishException(
                result);
        }
    }
}